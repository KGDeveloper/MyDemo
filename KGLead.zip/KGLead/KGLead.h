//
//  KGLead.h
//  KGLeftBox
//
//  Created by KG on 2017/11/20.
//  Copyright © 2017年 KG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KGLead : UIView

/**
 用来显示引导页的滚动视图
 */
@property (nonatomic,strong)UIScrollView *leadView;
/**
 引导页展示完后点击按钮进入APP
 */
@property (nonatomic,strong)UIButton *intoBtu;
/**
 用来存储显示引导页的数组
 */
@property (nonatomic,strong)NSMutableArray *photoArr;
/**
 引导页联动控件
 */
@property (nonatomic,strong)UIPageViewController *pageController;
/**
 先加载的imageView
 */
@property (nonatomic,strong)UIImageView *verbImg;
/**
 后加载的imageView
 */
@property (nonatomic,strong)UIImageView *nounImg;

/**
 引导页重写初始化方法

 @param frame 显示的界面大小
 @param type 是否带按钮
 @return view
 */
- (instancetype)initWithFrame:(CGRect)frame type:(NSInteger)type;

@end
