//
//  KGLead.m
//  KGLeftBox
//
//  Created by KG on 2017/11/20.
//  Copyright © 2017年 KG. All rights reserved.
//

#import "KGLead.h"

@implementation KGLead

- (instancetype)initWithFrame:(CGRect)frame type:(NSInteger)type{
    
    self = [super initWithFrame:frame];
    
    if (self) {
        
        [self createDataArr];
        [self createUI];
        
        UISwipeGestureRecognizer *swipeleft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeleftSwipe:)];
        
        [swipeleft setNumberOfTouchesRequired:1];
        
        [swipeleft setDirection:UISwipeGestureRecognizerDirectionRight];
        
        [self addGestureRecognizer:swipeleft];
        
        UISwipeGestureRecognizer *swiperight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swiperightSwipe:)];
        
        [swiperight setNumberOfTouchesRequired:1];
        
        [swiperight setDirection:UISwipeGestureRecognizerDirectionLeft];
        
        [self addGestureRecognizer:swiperight];
        
    }
    
    return self;
}

- (void) swipeleftSwipe:(UISwipeGestureRecognizer *)sender{

    if (_verbImg.tag == 101) {
        _verbImg.tag = 102;
        _nounImg.tag = 105;
        _verbImg.image = [UIImage imageNamed:_photoArr[2]];
        _nounImg.image = [UIImage imageNamed:_photoArr[3]];
        [self insertSubview:_verbImg atIndex:0];
    }else if (_verbImg.tag == 103){
        _verbImg.tag = 104;
        _nounImg.tag = 107;
        _verbImg.image = [UIImage imageNamed:_photoArr[0]];
        _nounImg.image = [UIImage imageNamed:_photoArr[1]];
        [self insertSubview:_verbImg atIndex:0];
    }else if (_nounImg.tag == 105){
        _verbImg.tag = 103;
        _nounImg.tag = 106;
        _verbImg.image = [UIImage imageNamed:_photoArr[2]];
        _nounImg.image = [UIImage imageNamed:_photoArr[1]];
        [self insertSubview:_nounImg atIndex:0];
    }else if (_nounImg.tag == 107){
        _verbImg.tag = 101;
        _verbImg.image = [UIImage imageNamed:_photoArr[0]];
        _nounImg.image = [UIImage imageNamed:_photoArr[3]];
        [self insertSubview:_nounImg atIndex:0];
    }
    
}

- (void) swiperightSwipe:(UISwipeGestureRecognizer *)sender{
    
    if (_verbImg.tag == 101) {
        _verbImg.tag = 102;
        _nounImg.tag = 105;
        _verbImg.image = [UIImage imageNamed:_photoArr[2]];
        _nounImg.image = [UIImage imageNamed:_photoArr[1]];
        [self insertSubview:_verbImg atIndex:0];
    }else if (_verbImg.tag == 103){
        _verbImg.tag = 104;
        _nounImg.tag = 107;
        _verbImg.image = [UIImage imageNamed:_photoArr[0]];
        _nounImg.image = [UIImage imageNamed:_photoArr[3]];
        [self insertSubview:_verbImg atIndex:0];
    }else if (_nounImg.tag == 105){
        _verbImg.tag = 103;
        _nounImg.tag = 106;
        _verbImg.image = [UIImage imageNamed:_photoArr[2]];
        _nounImg.image = [UIImage imageNamed:_photoArr[3]];
        [self insertSubview:_nounImg atIndex:0];
    }else if (_nounImg.tag == 107){
        _verbImg.tag = 101;
        _verbImg.image = [UIImage imageNamed:_photoArr[0]];
        _nounImg.image = [UIImage imageNamed:_photoArr[1]];
        [self insertSubview:_nounImg atIndex:0];
    }
    
    
    
    
}

- (void)createDataArr{
    _photoArr = [NSMutableArray array];
    for (int i = 1; i < 5; i++) {
        [_photoArr addObject:[NSString stringWithFormat:@"lead%d.png",i]];
    }
}

- (void)createUI{
//    _leadView = [[UIScrollView alloc]initWithFrame:self.frame];
//    [self addSubview:_leadView];
    
    _verbImg = [[UIImageView alloc]initWithFrame:self.frame];
    _verbImg.image = [UIImage imageNamed:_photoArr[0]];
    _verbImg.tag = 101;
    [self addSubview:_verbImg];
    
    _nounImg = [[UIImageView alloc]initWithFrame:self.frame];
    _nounImg.image = [UIImage imageNamed:_photoArr[1]];
    [self addSubview:_nounImg];
    [self insertSubview:_nounImg atIndex:0];
    
    
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
