//
//  KGLoginView.h
//  KGLeftBox
//
//  Created by KG on 2017/11/15.
//  Copyright © 2017年 KG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KGForgetViewController.h"
#import "KGRegisterViewController.h"

@interface KGLoginView : UIView
/**
 用户名
 */
@property (nonatomic,strong)UITextField *userName;
/**
 密码
 */
@property (nonatomic,strong)UITextField *passWoed;
/**
 登录按钮
 */
@property (nonatomic,strong)UIButton *loginBtu;
/**
 注册按钮
 */
@property (nonatomic,strong)UIButton *registerBtu;
/**
 忘记密码
 */
@property (nonatomic,strong)UIButton *forgetBtu;
/**
 注册按钮点击回调
 */
@property (nonatomic,copy)void(^registerBtuClick)(KGRegisterViewController *registerCv);
/**
 忘记密码按钮点击事件回调
 */
@property (nonatomic,copy)void(^forgetBtuClick)(KGForgetViewController *forgetCv);
/**
 完成登录后改变导航栏按钮
 */
@property (nonatomic,copy)void(^changeNavTitle)(NSString *title);

- (instancetype)initWithFrame:(CGRect)frame;

@end
