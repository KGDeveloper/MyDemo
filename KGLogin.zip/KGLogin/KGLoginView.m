//
//  KGLoginView.m
//  KGLeftBox
//
//  Created by KG on 2017/11/15.
//  Copyright © 2017年 KG. All rights reserved.
//

#import "KGLoginView.h"

#define KGscreenWidth [UIScreen mainScreen].bounds.size.width
#define KGscreenHeight [UIScreen mainScreen].bounds.size.height

#define KGYellowColor [UIColor colorWithRed:255/255.0 green:209/255.0 blue:43/255.0 alpha:1]

@implementation KGLoginView

- (instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        [self creatUI];
    }
    return self;
}

- (void)creatUI{
    
    UIImageView *kg = [[UIImageView alloc]initWithFrame:CGRectMake(KGscreenWidth/2 - 100*1023/658/2,25, 100*1023/658,100)];
    kg.image = [UIImage imageNamed:@"KG"];
    kg.layer.borderColor = [UIColor clearColor].CGColor;
    kg.layer.borderWidth = 1.0f;
    kg.layer.cornerRadius = 50.0f;
    kg.layer.masksToBounds = YES;
    [self addSubview:kg];
    
    _userName = [[UITextField alloc]initWithFrame:CGRectMake(10, 150,KGscreenWidth - 20 , 50)];
    _userName.placeholder = @"请输入账号";
    _userName.textAlignment = NSTextAlignmentCenter;
    _userName.layer.borderColor = KGYellowColor.CGColor;
    _userName.layer.borderWidth = 1.0f;
    _userName.layer.cornerRadius = 10.0f;
    _userName.layer.masksToBounds = YES;
    [self addSubview:_userName];
    
    _passWoed = [[UITextField alloc]initWithFrame:CGRectMake(10, 210,KGscreenWidth - 20 , 50)];
    _passWoed.placeholder = @"请输入密码";
    _passWoed.textAlignment = NSTextAlignmentCenter;
    _passWoed.layer.borderColor = KGYellowColor.CGColor;
    _passWoed.layer.borderWidth = 1.0f;
    _passWoed.layer.cornerRadius = 10.0f;
    _passWoed.layer.masksToBounds = YES;
    [self addSubview:_passWoed];
    
    _loginBtu = [[UIButton alloc]initWithFrame:CGRectMake(KGscreenWidth/2 + 5, 270, KGscreenWidth/2 - 15, 50)];
    [_loginBtu setTitle:@"登录" forState:UIControlStateNormal];
    [_loginBtu setTitleColor:KGYellowColor forState:UIControlStateNormal];
    _loginBtu.layer.borderColor = KGYellowColor.CGColor;
    _loginBtu.layer.borderWidth = 1.0f;
    _loginBtu.layer.cornerRadius = 10.0f;
    _loginBtu.layer.masksToBounds = YES;
    [_loginBtu addTarget:self action:@selector(loginBtuClick:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_loginBtu];
    
    _registerBtu = [[UIButton alloc]initWithFrame:CGRectMake(10, 270, KGscreenWidth/2 - 15, 50)];
    [_registerBtu setTitle:@"注册" forState:UIControlStateNormal];
    [_registerBtu setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    _registerBtu.layer.borderColor = KGYellowColor.CGColor;
    _registerBtu.layer.borderWidth = 1.0f;
    _registerBtu.layer.cornerRadius = 10.0f;
    _registerBtu.layer.masksToBounds = YES;
    [_registerBtu addTarget:self action:@selector(registerBtuClick:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_registerBtu];
    
    _forgetBtu = [[UIButton alloc]initWithFrame:CGRectMake(KGscreenWidth - 100, 320, 100, 50)];
    [_forgetBtu setTitle:@"忘记密码？" forState:UIControlStateNormal];
    [_forgetBtu setTitleColor:KGYellowColor forState:UIControlStateNormal];
    [_forgetBtu addTarget:self action:@selector(forgetBtuClick:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_forgetBtu];
}

#pragma mark -登录按钮的点击事件-
- (void)loginBtuClick:(UIButton *)sender{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setObject:_passWoed.text forKey:_userName.text];
//    [[NSUserDefaults standardUserDefaults] setObject:dic forKey:@"IsLogin"];
    if (self.changeNavTitle) {
        self.changeNavTitle(@"首页");
    }
    [self removeFromSuperview];
}

#pragma mark -注册按钮的点击事件-
- (void)registerBtuClick:(UIButton *)sender{
    KGRegisterViewController *registerCV = [[KGRegisterViewController alloc]init];
    if (self.registerBtuClick) {
        self.registerBtuClick(registerCV);
    }
}

#pragma mark -忘记密码按钮的点击事件-
- (void)forgetBtuClick:(UIButton *)sender{
    KGForgetViewController *forgetCv = [[KGForgetViewController alloc]init];
    if (self.forgetBtuClick) {
        self.forgetBtuClick(forgetCv);
    }
}

#pragma mark -监听界面点击-
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [_userName resignFirstResponder];
    [_passWoed resignFirstResponder];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
