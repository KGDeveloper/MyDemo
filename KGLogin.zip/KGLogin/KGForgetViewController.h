//
//  KGForgetViewController.h
//  KGLeftBox
//
//  Created by KG on 2017/11/15.
//  Copyright © 2017年 KG. All rights reserved.
//

#import "KGBaseViewController.h"

@interface KGForgetViewController : KGBaseViewController

@end
