//
//  KGDrawClarmClockView.h
//  爱智物联
//
//  Created by KG on 2017/11/25.
//  Copyright © 2017年 KG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KGDrawClarmClockView : UIView

@end
