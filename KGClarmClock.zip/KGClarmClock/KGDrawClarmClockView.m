//
//  KGDrawClarmClockView.m
//  爱智物联
//
//  Created by KG on 2017/11/25.
//  Copyright © 2017年 KG. All rights reserved.
//

#import "KGDrawClarmClockView.h"

@implementation KGDrawClarmClockView

- (instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    if (self) {
        
        self.backgroundColor = [UIColor colorWithRed:247/255.0 green:247/255.0 blue:247/255.0 alpha:1];
        
        [self drawClarm];
    }
    return self;
}


- (void)drawClarm{
    /*
     *画实线圆
     */
    CAShapeLayer *solidLine =  [CAShapeLayer layer];
    CGMutablePathRef solidPath =  CGPathCreateMutable();
    solidLine.lineWidth = 2.0f ;
    solidLine.strokeColor = [UIColor colorWithRed:222/255.0 green:222/255.0 blue:222/255.0 alpha:1].CGColor;
    solidLine.fillColor = [UIColor clearColor].CGColor;
    CGPathAddEllipseInRect(solidPath, nil, CGRectMake(self.frame.size.width/2 - 100,  self.frame.size.height/2 - 150, 200.0f, 200.0f));
    solidLine.path = solidPath;
    CGPathRelease(solidPath);
    [self.layer addSublayer:solidLine];
    
    //秒
    for (int i = 0; i <= 12; i++) {
        
        UILabel *lineLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 200, 2)];
        lineLabel.center = CGPointMake(self.frame.size.width/2, self.frame.size.height/2 - 50);
        lineLabel.backgroundColor = [UIColor colorWithRed:222/255.0 green:222/255.0 blue:222/255.0 alpha:1];
        [self addSubview:lineLabel];
        CGAffineTransform transform = CGAffineTransformMakeRotation(i*30 * M_PI/360);
        lineLabel.transform = transform;
    }
    
    UILabel *bottomLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 180, 180)];
    bottomLabel.center = CGPointMake(self.frame.size.width/2, self.frame.size.height/2 - 50);
    bottomLabel.backgroundColor = [UIColor colorWithRed:247/255.0 green:247/255.0 blue:247/255.0 alpha:1];
    bottomLabel.layer.cornerRadius = 90.0f;
    bottomLabel.layer.masksToBounds = YES;
    [self addSubview:bottomLabel];
    
    //分
    for (int i = 0; i <= 6; i++) {
        
        UILabel *lineLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 200, 2)];
        lineLabel.center = CGPointMake(self.frame.size.width/2, self.frame.size.height/2 - 50);
        lineLabel.backgroundColor = [UIColor colorWithRed:222/255.0 green:222/255.0 blue:222/255.0 alpha:1];
        [self addSubview:lineLabel];
        CGAffineTransform transform = CGAffineTransformMakeRotation(i*60 * M_PI/360);
        lineLabel.transform = transform;
    }
    
    UILabel *centerLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 165, 165)];
    centerLabel.center = CGPointMake(self.frame.size.width/2, self.frame.size.height/2 - 50);
    centerLabel.backgroundColor = [UIColor colorWithRed:247/255.0 green:247/255.0 blue:247/255.0 alpha:1];
    centerLabel.layer.cornerRadius = 82.5f;
    centerLabel.layer.masksToBounds = YES;
    [self addSubview:centerLabel];
    
    //时
    for (int i = 0; i <= 2; i++) {
        
        UILabel *lineLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 200, 2)];
        lineLabel.center = CGPointMake(self.frame.size.width/2, self.frame.size.height/2 - 50);
        lineLabel.backgroundColor = [UIColor colorWithRed:222/255.0 green:222/255.0 blue:222/255.0 alpha:1];
        [self addSubview:lineLabel];
        CGAffineTransform transform = CGAffineTransformMakeRotation(i*180 * M_PI/360);
        lineLabel.transform = transform;
    }
    
    UILabel *topLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 150, 150)];
    topLabel.center = CGPointMake(self.frame.size.width/2, self.frame.size.height/2 - 50);
    topLabel.backgroundColor = [UIColor colorWithRed:247/255.0 green:247/255.0 blue:247/255.0 alpha:1];
    topLabel.layer.cornerRadius = 75.0f;
    topLabel.layer.masksToBounds = YES;
    [self addSubview:topLabel];
    
    UILabel *oneLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.frame.size.width/2 - 5, self.frame.size.height/2 - 120, 10, 10)];
    oneLabel.text = @"12";
    oneLabel.font = [UIFont systemFontOfSize:8.0f];
    [self addSubview:oneLabel];
    
    UILabel *twoLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.frame.size.width/2 - 70, self.frame.size.height/2 - 52, 6, 6)];
    twoLabel.text = @"3";
    twoLabel.font = [UIFont systemFontOfSize:8.0f];
    [self addSubview:twoLabel];
    
    UILabel *threeLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.frame.size.width/2 - 3, self.frame.size.height/2 + 15, 6, 6)];
    threeLabel.text = @"6";
    threeLabel.font = [UIFont systemFontOfSize:8.0f];
    [self addSubview:threeLabel];
    
    UILabel *fourLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.frame.size.width/2 + 70, self.frame.size.height/2 - 52, 6, 6)];
    fourLabel.text = @"9";
    fourLabel.textAlignment = NSTextAlignmentLeft;
    fourLabel.font = [UIFont systemFontOfSize:8.0f];
    [self addSubview:fourLabel];
    
}


//- (void)drawRect:(CGRect)rect {
//
//    [super drawRect:rect];
//
//    CGRect frame = CGRectMake(50, 100, 100, 100);
//    /*画填充圆
//     */
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    [[UIColor whiteColor] set];
//    CGContextFillRect(context, rect);
//
//    CGContextAddEllipseInRect(context, frame);
//    [[UIColor orangeColor] set];
//    CGContextFillPath(context);
//
//}


@end
