//
//  KGRequestJSON.h
//  KGLeftBox
//
//  Created by KG on 2017/11/14.
//  Copyright © 2017年 KG. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 成功回调

 @param msg 回调参数
 @param data 回调数据
 */
typedef void(^requestJosnSucc)(NSString *msg,id data);
/**
 失败回调

 @param error 回调参数
 */
typedef void(^requestJosnFail)(NSString *error);

@interface KGRequestJSON : NSObject

/**
 获取单利

 @return 返回获取到的单利
 */
+ (KGRequestJSON *)shareInstance;

- (void)requeestJokeListWithAPPKEY:(NSString *)appkey sort:(NSString *)sort page:(NSInteger)page pagesize:(NSInteger)pagesize time:(NSString *)time;

@end
