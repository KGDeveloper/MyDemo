//
//  KGRequestJSON.m
//  KGLeftBox
//
//  Created by KG on 2017/11/14.
//  Copyright © 2017年 KG. All rights reserved.
//

#import "KGRequestJSON.h"

@implementation KGRequestJSON

static KGRequestJSON *sharedObj = nil;

+ (KGRequestJSON *) shareInstance{
    
    @synchronized (self){
        if (sharedObj == nil) {
            sharedObj = [[self alloc] init];
        }
    }
    return sharedObj;
}

- (void)requeestJokeListWithAPPKEY:(NSString *)appkey sort:(NSString *)sort page:(NSInteger)page pagesize:(NSInteger)pagesize time:(NSString *)time{
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    [dic setObject:appkey forKey:@"key"];
    [dic setObject:sort forKey:@"sort"];
    [dic setObject:[NSNumber numberWithInteger:page] forKey:@"page"];
    [dic setObject:[NSNumber numberWithInteger:pagesize] forKey:@"pagesize"];
    [dic setObject:time forKey:@"time"];
    
    
}

@end
