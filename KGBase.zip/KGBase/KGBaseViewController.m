//
//  KGBaseViewController.m
//  KGLeftBox
//
//  Created by KG on 2017/11/14.
//  Copyright © 2017年 KG. All rights reserved.
//

#import "KGBaseViewController.h"

@interface KGBaseViewController ()

@end

@implementation KGBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置导航栏状态
    [self.navigationController.navigationBar setBarStyle:UIBarStyleBlack];
    
    //设置view的背景色
    [self.view setBackgroundColor:[UIColor whiteColor]];
    
    //设置导航栏的颜色
    [self.navigationController.navigationBar setBarTintColor:[UIColor blackColor]];
    
    //设置导航栏的字体大小以及颜色，是一个字典类型
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor], NSFontAttributeName:[UIFont boldSystemFontOfSize:17.0f]}];
}

/**
 导航栏左侧按钮

 @param title 如若是显示文字填写title，否则填写nil
 @param icon 如若是显示图片填写icon，否则填写nil
 */
- (void)setUpLeftNavButtonItmeTitle:(NSString *)title icon:(NSString *)icon{
    
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    leftButton.frame = CGRectMake(0, 0, 30, 30);
    
    [leftButton setTitle:title forState:UIControlStateNormal];
    
    [leftButton setImage:[UIImage imageNamed:icon] forState:UIControlStateNormal];
    
    [leftButton addTarget:self action:@selector(leftBarItmeClick:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *leftItme = [[UIBarButtonItem alloc]initWithCustomView:leftButton];
    
    self.navigationItem.leftBarButtonItem = leftItme;
    
}

/**
 导航栏左侧按钮

 @param sender 按钮，UIButton *类型
 */
- (void)leftBarItmeClick:(UIButton *)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}

/**
 导航栏右侧按钮
 
 @param title 如若是显示文字填写title，否则填写nil
 @param icon 如若是显示图片填写icon，否则填写nil
 */
- (void)setUpRightNavButtonItmeTitle:(NSString *)title icon:(NSString *)icon{
    
    UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    rightButton.frame = CGRectMake(0, 0, 30, 30);
    
    [rightButton setTitle:title forState:UIControlStateNormal];
    
    [rightButton setImage:[UIImage imageNamed:icon] forState:UIControlStateNormal];
    
    [rightButton addTarget:self action:@selector(rightBarItmeClick:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *rightItme = [[UIBarButtonItem alloc]initWithCustomView:rightButton];
    
    self.navigationItem.leftBarButtonItem = rightItme;
    
}

/**
 导航栏右侧按钮
 
 @param sender 按钮，UIButton *类型
 */
- (void)rightBarItmeClick:(UIButton *)sender{
    
}

/**
 警告框

 @param title 显示警告框标题
 @param message 显示警告框信息
 @param name 按钮显示信息
 */
- (void)alertViewControllerTitle:(NSString *)title message:(NSString *)message name:(NSString *)name type:(NSInteger)type preferredStyle:(UIAlertControllerStyle)preferredStyle{
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:preferredStyle];
    
    //如果参数是0表示只有一个按钮点击后警告框消失
    if (type == 0) {
        
        UIAlertAction *action = [UIAlertAction actionWithTitle:name style:UIAlertActionStyleDefault handler:nil];
        
        [alert addAction:action];
    }else{
        
        UIAlertAction *sureAct = [UIAlertAction actionWithTitle:name style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [self alertControllerAction];
        }];
        
        UIAlertAction *canalAct = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        
        [alert addAction:sureAct];
        [alert addAction:canalAct];
    }
    
    
    
    [self presentViewController:alert animated:YES completion:nil];
    
}

#pragma mark - 警告框点击按钮后要执行的方法在这里实现-
- (void)alertControllerAction{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
