//
//  KGPickerView.h
//  爱智物联
//
//  Created by KG on 2017/11/25.
//  Copyright © 2017年 KG. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface KGPickerView : UIView

@property (nonatomic,copy) void(^sendStringTime)(NSString *time);

- (instancetype)initWithFrame:(CGRect)frame;

@end
