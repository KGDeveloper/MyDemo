//
//  KGPickerView.m
//  爱智物联
//
//  Created by KG on 2017/11/25.
//  Copyright © 2017年 KG. All rights reserved.
//

#import "KGPickerView.h"

@interface KGPickerView()<UIPickerViewDelegate,UIPickerViewDataSource>{
    
    NSString *oneStr;
    NSString *twoStr;
    NSString *threeStr;
    
}

@property (nonatomic,strong) UIPickerView *timerPickerView;
@property (nonatomic,strong) NSMutableArray *hourArr;
@property (nonatomic,strong) NSMutableArray *minArr;

@end

@implementation KGPickerView

- (instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    if (self) {
        
        _hourArr = [NSMutableArray array];
        _minArr = [NSMutableArray array];
        
        for (int i = 0; i < 24; i++) {
            [_hourArr addObject:[NSString stringWithFormat:@"%d",i]];
        }
        for (int i = 0; i < 60; i++) {
            if (i<10) {
                [_minArr addObject:[NSString stringWithFormat:@"0%d",i]];
            }else{
                [_minArr addObject:[NSString stringWithFormat:@"%d",i]];
            }
            
        }
        
        [self createUI];
    }
    
    return self;
    
}

- (void)createUI{
    
    UILabel *lineLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, 30)];
    lineLabel.backgroundColor = [UIColor lightGrayColor];
    [self addSubview:lineLabel];
    
    UIButton *finishBtu = [[UIButton alloc]initWithFrame:CGRectMake(self.frame.size.width - 100, 0, 50, 30)];
    [finishBtu setTitle:@"完成" forState:UIControlStateNormal];
    [finishBtu setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [finishBtu addTarget:self action:@selector(finishClick:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:finishBtu];
    
    _timerPickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, 30, self.frame.size.width, self.frame.size.height - 30)];
    _timerPickerView.delegate = self;
    _timerPickerView.dataSource = self;
    [self addSubview:_timerPickerView];
    
}

#pragma mark -实现代理方法-
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 3;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    if (component == 0) {
        return 24;
    }else{
        return 60;
    }
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    if (component == 0) {
        return _hourArr[row];
    }else{
        return _minArr[row];
    }
    
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component{
    return self.frame.size.width/3;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    if (component == 0) {
        oneStr = _hourArr[row];
    }else if (component == 1){
        twoStr = _minArr[row];
    }else{
        threeStr = _minArr[row];
    }
}

- (void)finishClick:(UIButton *)sender{

    if (self.sendStringTime) {
        self.sendStringTime([NSString stringWithFormat:@"%@:%@:%@",oneStr,twoStr,threeStr]);
    }
    
    [self removeFromSuperview];
}

@end
