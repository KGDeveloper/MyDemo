//
//  KGScrollView.m
//  KGLeftBox
//
//  Created by KG on 2017/11/21.
//  Copyright © 2017年 KG. All rights reserved.
//

#import "KGScrollView.h"

@interface KGScrollView(){
    
}

/**
 用来加载轮播图
 */
@property (nonatomic,strong)UIScrollView *scrollView;
/**
 表示轮播图放到第几页了
 */
@property (nonatomic,strong)UIPageControl *pageControl;
/**
 用来存放图片
 */
@property (nonatomic,strong)NSMutableArray *photoArr;
/**
 定时器，用来控制滚动视图
 */
@property (nonatomic,strong)NSTimer *timer;
@property (nonatomic,assign)int number;

@end

@implementation KGScrollView

- (instancetype)initWithFrame:(CGRect)frame time:(NSInteger)time imageArr:(NSMutableArray *)imageArr{
    
    self = [super initWithFrame:frame];
    
    if (self) {
        _number = 0;
        _photoArr = [NSMutableArray array];
        _photoArr = imageArr;
        [self createUIScrollViewWithArr:imageArr];
        _timer = [NSTimer scheduledTimerWithTimeInterval:time target:self selector:@selector(timerChangeScrollView) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
    
    return self;
}

/**
 释放定时器
 */
- (void)timerDidReless{
    [_timer invalidate];
    _timer = nil;
}

/**
 创建轮播图

 @param photoArr 轮播图需要加载的图片数组
 */
- (void)createUIScrollViewWithArr:(NSMutableArray *)photoArr{
    
    _scrollView = [[UIScrollView alloc]initWithFrame:self.frame];
    _scrollView.bounces = NO;
    _scrollView.scrollEnabled = YES;
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.showsHorizontalScrollIndicator = NO;
    _scrollView.contentSize = CGSizeMake(self.frame.size.width * photoArr.count, self.frame.size.height);
    [self addSubview:_scrollView];
    
    for (int i = 0; i < photoArr.count; i++) {
        UIImageView *kgImageView = [[UIImageView alloc]initWithFrame:CGRectMake(self.frame.size.width * i, 0, self.frame.size.width, self.frame.size.height)];
        kgImageView.image = [UIImage imageNamed:photoArr[i]];
        [_scrollView addSubview:kgImageView];
    }
}

/**
 定时器执行方法
 */
- (void)timerChangeScrollView{
    if (_number < _photoArr.count - 1) {
        _number++;
        _scrollView.contentOffset = CGPointMake(self.frame.size.width * _number, 0);
    }else{
        _number = 0;
        _scrollView.contentOffset = CGPointMake(self.frame.size.width * _number, 0);
    }
    
}


@end
