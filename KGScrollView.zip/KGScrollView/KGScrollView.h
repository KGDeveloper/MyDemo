//
//  KGScrollView.h
//  KGLeftBox
//
//  Created by KG on 2017/11/21.
//  Copyright © 2017年 KG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KGScrollView : UIView

/**
 重写View的初始化方法

 @param frame 给View大小
 @param time 设置每个图片轮播时间间隔,建议设置为0.5~0.1之间
 @param imageArr 存储图片的数组
 @return 带有轮播的view
 */
- (instancetype)initWithFrame:(CGRect)frame time:(NSInteger)time imageArr:(NSMutableArray *)imageArr;

/**
 用来释放定时器
 */
- (void)timerDidReless;

@end
