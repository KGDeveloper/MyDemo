//
//  KGTableView.h
//  KGLeftBox
//
//  Created by KG on 2017/11/22.
//  Copyright © 2017年 KG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KGTableView : UIView

/**
 重写初始化方法

 @param frame 给定tableView大小
 @param style 设置tableView的风格
 @return 返回一个tableView
 */
- (instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style;

/**
 从控制器发送一个数组过来

 @param dataArr 数组是存有model的
 */
- (void)sendArrToView:(NSMutableArray *)dataArr;

@end
