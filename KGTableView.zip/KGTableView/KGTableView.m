//
//  KGTableView.m
//  KGLeftBox
//
//  Created by KG on 2017/11/22.
//  Copyright © 2017年 KG. All rights reserved.
//

#import "KGTableView.h"

@interface KGTableView()<UITableViewDelegate,UITableViewDataSource>

/**
 显示信息的列表视图
 */
@property (nonatomic,strong)UITableView *listTableView;
/**
 保存接受数组model的数组
 */
@property (nonatomic,strong)NSMutableArray *modelArr;


@end

@implementation KGTableView

- (instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style{
    
    self = [super initWithFrame:frame];
    if (self) {
        
        _modelArr = [NSMutableArray array];
        
        [self createTableViewWithStyle:style];
    }
    return self;
}

- (void)sendArrToView:(NSMutableArray *)dataArr{
    
    [_modelArr removeAllObjects];
    _modelArr = dataArr;
    
    
}

- (void)createTableViewWithStyle:(UITableViewStyle)style{
    
    _listTableView = [[UITableView alloc]initWithFrame:self.frame style:style];
    _listTableView.delegate = self;
    _listTableView.dataSource = self;
    _listTableView.tableFooterView = [[UIView alloc]init];
    [self addSubview:_listTableView];
    
}

#pragma mark -遵守tableView的协议-
//设置tableView的分组数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

//设置tableView的行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _modelArr.count;
}

//设置tableView的显示内容
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
    }
    return cell;
}

//设置分组头
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return @"开始";
}

//设置分组尾
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section{
    return @"结束";
}

//设置右侧检索导航栏
-(NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    NSArray *aa = @[@"A", @"B", @"C"];
    return aa;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
